Insert INTO note (course_Code, course_name, date, notes, title)
values ('PROG11111', 'Java1', '01-01-2022', 'Hello', 'java-note'),
('DBAS23231', 'Database', '01-13-2022', 'This is a note for data base', 'dbas-note');